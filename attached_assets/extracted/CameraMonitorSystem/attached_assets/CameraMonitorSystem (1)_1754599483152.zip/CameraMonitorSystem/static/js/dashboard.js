// Dashboard JavaScript pour le monitoring des caméras

class Dashboard {
    constructor() {
        this.init();
        this.startAutoRefresh();
    }

    init() {
        console.log('Dashboard initialisé');
        this.bindEvents();
    }

    bindEvents() {
        // Pas d'événements spécifiques pour le moment
    }

    // Actualiser les statistiques du dashboard
    async actualiserStats() {
        try {
            const response = await fetch('/api/dashboard/stats');
            const stats = await response.json();
            
            if (response.ok) {
                this.mettreAJourStats(stats);
            } else {
                console.error('Erreur lors de la récupération des stats:', stats.error);
            }
        } catch (error) {
            console.error('Erreur réseau:', error);
        }
    }

    // Mettre à jour les éléments de statistiques
    mettreAJourStats(stats) {
        // Mettre à jour les cartes de statistiques
        const elements = {
            'total_clients': stats.total_clients,
            'total_equipements': stats.total_equipements,
            'equipements_en_ligne': stats.equipements_en_ligne,
            'equipements_hors_ligne': stats.equipements_hors_ligne
        };

        Object.entries(elements).forEach(([key, value]) => {
            const element = document.querySelector(`[data-stat="${key}"]`);
            if (element) {
                element.textContent = value;
            }
        });

        // Mettre à jour le graphique si il existe
        if (window.equipementsChart) {
            window.equipementsChart.data.datasets[0].data = [
                stats.equipements_en_ligne,
                stats.equipements_hors_ligne
            ];
            window.equipementsChart.update();
        }
    }

    // Obtenir le statut de tous les équipements
    async obtenirStatutEquipements() {
        try {
            const response = await fetch('/api/equipements/statut');
            const equipements = await response.json();
            
            if (response.ok) {
                return equipements;
            } else {
                console.error('Erreur lors de la récupération du statut:', equipements.error);
                return [];
            }
        } catch (error) {
            console.error('Erreur réseau:', error);
            return [];
        }
    }

    // Démarrer l'actualisation automatique
    startAutoRefresh() {
        // Actualiser les stats toutes les 30 secondes
        setInterval(() => {
            if (document.visibilityState === 'visible') {
                this.actualiserStats();
            }
        }, 30000);
    }

    // Afficher une notification
    afficherNotification(message, type = 'info') {
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${type} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        const container = document.querySelector('.container');
        if (container) {
            container.insertBefore(alertDiv, container.firstChild);
            
            // Supprimer automatiquement après 5 secondes
            setTimeout(() => {
                if (alertDiv.parentNode) {
                    alertDiv.remove();
                }
            }, 5000);
        }
    }

    // Formater une durée en format lisible
    formaterDuree(millisecondes) {
        const secondes = Math.floor(millisecondes / 1000);
        const minutes = Math.floor(secondes / 60);
        const heures = Math.floor(minutes / 60);
        const jours = Math.floor(heures / 24);

        if (jours > 0) {
            return `${jours} jour${jours > 1 ? 's' : ''}`;
        } else if (heures > 0) {
            return `${heures} heure${heures > 1 ? 's' : ''}`;
        } else if (minutes > 0) {
            return `${minutes} minute${minutes > 1 ? 's' : ''}`;
        } else {
            return `${secondes} seconde${secondes > 1 ? 's' : ''}`;
        }
    }

    // Obtenir la couleur de statut pour un équipement
    obtenirCouleurStatut(estEnLigne) {
        return estEnLigne ? 'success' : 'danger';
    }

    // Obtenir l'icône de statut pour un équipement
    obtenirIconeStatut(estEnLigne) {
        return estEnLigne ? 'fa-check-circle' : 'fa-times-circle';
    }
}

// Utilitaires globaux
window.DashboardUtils = {
    // Formater une date en français
    formaterDate(date) {
        return new Date(date).toLocaleDateString('fr-FR', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    },

    // Copier du texte dans le presse-papier
    async copierTexte(texte) {
        try {
            await navigator.clipboard.writeText(texte);
            return true;
        } catch (err) {
            console.error('Erreur lors de la copie:', err);
            return false;
        }
    },

    // Valider une adresse IP
    validerIP(ip) {
        const regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
        return regex.test(ip);
    },

    // Obtenir l'état de la connexion réseau
    obtenirEtatConnexion() {
        return navigator.onLine;
    }
};

// Initialiser le dashboard quand le DOM est prêt
document.addEventListener('DOMContentLoaded', () => {
    window.dashboard = new Dashboard();
    
    // Gérer les changements de visibilité de la page
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') {
            console.log('Page visible, actualisation des données...');
            window.dashboard.actualiserStats();
        }
    });
    
    // Gérer les changements de connexion
    window.addEventListener('online', () => {
        window.dashboard.afficherNotification('Connexion réseau rétablie', 'success');
    });
    
    window.addEventListener('offline', () => {
        window.dashboard.afficherNotification('Connexion réseau perdue', 'warning');
    });
});
