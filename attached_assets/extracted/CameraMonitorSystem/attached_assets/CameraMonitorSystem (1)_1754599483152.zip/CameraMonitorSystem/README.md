# Système de Monitoring des Caméras de Surveillance

## Description
Ce projet est un système web complet de monitoring pour les caméras de surveillance et équipements DVR/NVR. Il permet de surveiller en temps réel l'état de connexion des équipements clients et de générer des alertes automatiques en cas de dysfonctionnement.

## Fonctionnalités principales

### 🎯 Monitoring en temps réel
- Surveillance automatique des équipements toutes les minutes
- Détection automatique des pannes et retours en ligne
- Interface web moderne avec mise à jour en temps réel

### 👥 Gestion des clients
- Ajout et gestion des informations clients
- Association des équipements aux clients
- Vue d'ensemble par client

### 📹 Gestion des équipements
- Support DVR, caméras et NVR
- Configuration IP et ports personnalisés
- Historique complet des connexions

### 🚨 Système d'alertes
- Alertes automatiques en cas de panne
- Notifications de retour en ligne
- Gestion des alertes lues/non lues

### 📊 Tableau de bord
- Statistiques globales en temps réel
- Graphiques de répartition des statuts
- Vue d'ensemble des alertes récentes

## Technologies utilisées

### Backend
- **Python 3.11** - Langage principal
- **Flask** - Framework web
- **SQLAlchemy** - ORM pour la base de données
- **APScheduler** - Planificateur de tâches
- **PostgreSQL** - Base de données de production
- **SQLite** - Base de données de développement

### Frontend
- **Bootstrap 5** - Framework CSS avec thème sombre
- **Chart.js** - Graphiques interactifs
- **Font Awesome** - Icônes
- **JavaScript vanilla** - Interactions client

## Installation et démarrage

### Prérequis
- Python 3.11+
- PostgreSQL (pour la production)

### Installation des dépendances
```bash
pip install -r requirements.txt
```

### Configuration de la base de données
Le projet supporte deux configurations :

**Développement (SQLite)**
```bash
# Aucune configuration requise, la base SQLite sera créée automatiquement
```

**Production (PostgreSQL)**
```bash
export DATABASE_URL="postgresql://user:password@localhost/monitoring_db"
export SESSION_SECRET="votre-clé-secrète-très-sécurisée"
```

### Démarrage de l'application
```bash
# Mode développement
python main.py

# Mode production avec Gunicorn
gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app
```

L'application sera accessible sur `http://localhost:5000`

## Structure du projet

```
monitoring_cameras/
├── app.py              # Configuration principale Flask
├── main.py             # Point d'entrée de l'application
├── models.py           # Modèles de base de données
├── routes.py           # Routes et endpoints API
├── scheduler.py        # Tâches de monitoring automatiques
├── templates/          # Templates HTML Jinja2
│   ├── base.html
│   ├── dashboard.html
│   ├── clients.html
│   ├── equipements.html
│   ├── history.html
│   └── alerts.html
├── static/
│   ├── css/
│   │   └── custom.css  # Styles personnalisés
│   └── js/
│       └── dashboard.js # JavaScript du tableau de bord
└── pyproject.toml      # Dépendances Python
```

## API Endpoints

### Endpoints web
- `GET /` - Tableau de bord principal
- `GET /clients` - Gestion des clients
- `GET /equipements` - Gestion des équipements
- `GET /historique` - Historique des connexions
- `GET /alertes` - Gestion des alertes

### API REST
- `POST /api/ping` - Réception des pings des équipements
- `GET /api/dashboard/stats` - Statistiques du tableau de bord
- `GET /api/equipements/statut` - Statut de tous les équipements
- `POST /api/alertes/marquer_lue/{id}` - Marquer une alerte comme lue

### Gestion des données
- `POST /ajouter_client` - Ajouter un nouveau client
- `POST /ajouter_equipement` - Ajouter un nouvel équipement

## Fonctionnement du monitoring

### Réception des pings
Les équipements (DVR/caméras) doivent envoyer des requêtes POST vers `/api/ping` avec :
```json
{
  "ip": "192.168.1.100",
  "equipement_id": 1,
  "response_time": 50,
  "message": "Statut OK"
}
```

### Détection automatique des pannes
- Un équipement est considéré "hors ligne" après 2 minutes sans ping
- Une alerte est générée automatiquement
- Le retour en ligne génère également une alerte

### Nettoyage automatique
- Historique des pings : conservé 30 jours
- Alertes lues : conservées 7 jours
- Nettoyage quotidien automatique

## Configuration des équipements

Pour que vos équipements envoient des pings automatiques, configurez-les pour envoyer des requêtes HTTP POST vers votre serveur :

**URL :** `http://votre-serveur:5000/api/ping`
**Méthode :** POST
**Content-Type :** application/json
**Fréquence :** Toutes les 1-2 minutes

## Sécurité

- Sessions Flask sécurisées
- Protection CSRF sur les formulaires
- Validation des données d'entrée
- Logs détaillés des actions

## Déploiement

### Replit
Le projet est configuré pour Replit avec :
- Workflow de démarrage automatique
- Configuration PostgreSQL
- Variables d'environnement sécurisées

### Autres plateformes
Compatible avec Heroku, Railway, et autres PaaS supportant Python/PostgreSQL.

## Maintenance

### Logs
Les logs sont configurés au niveau DEBUG et incluent :
- Actions des utilisateurs
- États des équipements
- Erreurs système
- Tâches planifiées

### Monitoring
- Auto-actualisation des interfaces toutes les 30 secondes
- Détection de perte de connexion réseau
- Notifications visuelles des changements d'état

## Support

Pour toute question ou problème :
1. Vérifiez les logs de l'application
2. Consultez la documentation des API
3. Vérifiez la configuration de la base de données

## Licence

Ce projet est un système professionnel de monitoring pour les entreprises d'installation de caméras de surveillance.