# Guide de Test Réseau - Simulation Caméra

## 🎯 **Objectif**
Tester votre système de monitoring avec un PC qui simule une caméra via câble Ethernet.

## 🔧 **Configuration Hardware**

### Option A : Connexion directe (câble Ethernet)
```
PC1 (Serveur monitoring) ←--ethernet--> PC2 (Caméra simulée)
```

### Option B : Réseau local existant (plus simple)
```
PC1 ←--réseau--> Routeur ←--réseau--> PC2
```

## ⚙️ **Configuration logicielle**

### **PC1 (Serveur de monitoring)**
1. **IP fixe** : `192.168.1.10` (si connexion directe)
2. **Application** : Votre système de monitoring sur port 5000
3. **Commande** : `python main.py`
4. **URL** : `http://192.168.1.10:5000`

### **PC2 (Caméra simulée)**
1. **IP fixe** : `192.168.1.100` (si connexion directe)
2. **Script** : `simulateur_camera.py`
3. **Commande** : `python simulateur_camera.py`

## 📋 **Étapes de configuration**

### **1. Configuration réseau (si connexion directe)**

**Sur PC1 (serveur) :**
```bash
# Windows
netsh interface ip set address "Ethernet" static 192.168.1.10 255.255.255.0

# Ou via Interface graphique :
Panneau de contrôle > Réseau > Propriétés carte Ethernet > IPv4
IP : 192.168.1.10
Masque : 255.255.255.0
```

**Sur PC2 (caméra) :**
```bash
# Windows
netsh interface ip set address "Ethernet" static 192.168.1.100 255.255.255.0

# Ou via Interface graphique :
IP : 192.168.1.100
Masque : 255.255.255.0
```

### **2. Test de connectivité**
```bash
# Depuis PC1, ping PC2
ping 192.168.1.100

# Depuis PC2, ping PC1
ping 192.168.1.10
```

### **3. Démarrage du serveur (PC1)**
```bash
cd dossier_monitoring
python main.py
```
→ Serveur accessible sur `http://192.168.1.10:5000`

### **4. Configuration dans l'interface web**
1. Ouvrir `http://192.168.1.10:5000`
2. Ajouter un équipement :
   - **Nom** : "Camera Test PC2"
   - **Type** : Camera
   - **IP** : `192.168.1.100`
   - **Port** : 80
3. Noter l'**ID** de l'équipement créé

### **5. Démarrage du simulateur (PC2)**
```bash
python simulateur_camera.py
```

**Configuration du simulateur :**
- **Serveur** : `http://192.168.1.10:5000`
- **IP caméra** : `192.168.1.100`
- **ID équipement** : (celui noté à l'étape 4)
- **Intervalle** : 60 secondes

## ✅ **Résultat attendu**

1. **PC2** envoie un ping toutes les minutes
2. **PC1** reçoit le ping et met à jour le statut
3. **Interface web** montre la caméra "En ligne"
4. **Historique** enregistre tous les pings

## 🔍 **Dépannage**

### **Problème : Pas de connexion entre PC**
- Vérifier les câbles Ethernet
- Vérifier les adresses IP avec `ipconfig`
- Tester avec `ping`

### **Problème : Serveur inaccessible**
- Vérifier que le serveur tourne sur port 5000
- Tester l'URL dans le navigateur
- Désactiver le pare-feu temporairement

### **Problème : Ping pas reçu**
- Vérifier l'ID d'équipement dans la base
- Vérifier les logs du serveur
- Tester manuellement avec curl

## 🎭 **Avantages de cette méthode**

✅ **Test réaliste** : Simule exactement une vraie caméra
✅ **Réseau réel** : Teste la connectivité réseau
✅ **Flexible** : Peut simuler plusieurs caméras
✅ **Déboguer** : Permet de voir les erreurs en temps réel
✅ **Formation** : Comprendre le fonctionnement

## 📡 **Extension possible**

- **Plusieurs simulateurs** : Lancer plusieurs instances
- **Simulations de panne** : Arrêter/redémarrer le simulateur
- **Différents réseaux** : Tester via VPN, Internet, etc.
- **Performance** : Mesurer la charge avec 50+ caméras simulées

Votre approche est parfaite pour valider le système avant déploiement réel !