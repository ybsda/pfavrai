# Guide d'Installation - Système de Monitoring Caméras

## 📥 Téléchargement

### Option 1: Via Replit (recommandé)
1. Accédez à votre projet sur Replit
2. Cliquez sur les trois points (⋯) dans l'arborescence des fichiers
3. Sélectionnez "Download as zip"

### Option 2: Via navigateur
1. Le fichier `monitoring_cameras.zip` est disponible dans votre workspace
2. Cliquez dessus pour le télécharger

## 🚀 Installation sur votre serveur

### Étape 1: Prérequis
```bash
# Ubuntu/Debian
sudo apt update
sudo apt install python3 python3-pip python3-venv postgresql postgresql-contrib

# CentOS/RHEL
sudo yum install python3 python3-pip postgresql postgresql-server
```

### Étape 2: Extraction du projet
```bash
# Extraire l'archive
unzip monitoring_cameras.zip
cd monitoring_cameras

# Créer un environnement virtuel
python3 -m venv venv
source venv/bin/activate
```

### Étape 3: Installation des dépendances
```bash
# Installer les packages Python
pip install Flask==3.0.0
pip install Flask-SQLAlchemy==3.1.1
pip install APScheduler==3.10.4
pip install Werkzeug==3.0.1
pip install psycopg2-binary==2.9.9
pip install email-validator==2.1.0
pip install gunicorn==21.2.0
```

### Étape 4: Configuration de la base de données

#### Option A: PostgreSQL (production)
```bash
# Créer la base de données
sudo -u postgres createdb monitoring_db
sudo -u postgres createuser monitoring_user
sudo -u postgres psql

# Dans PostgreSQL
ALTER USER monitoring_user WITH ENCRYPTED PASSWORD 'votre_mot_de_passe';
GRANT ALL PRIVILEGES ON DATABASE monitoring_db TO monitoring_user;
\q
```

#### Option B: SQLite (développement)
Aucune configuration requise, la base sera créée automatiquement.

### Étape 5: Variables d'environnement
```bash
# Créer le fichier .env
cat > .env << EOF
# Pour PostgreSQL
DATABASE_URL=postgresql://monitoring_user:votre_mot_de_passe@localhost/monitoring_db

# Pour SQLite (alternative)
# DATABASE_URL=sqlite:///monitoring.db

# Clé secrète pour les sessions
SESSION_SECRET=votre-cle-secrete-tres-longue-et-securisee
EOF
```

### Étape 6: Démarrage de l'application

#### Mode développement
```bash
# Charger les variables d'environnement
export $(cat .env | xargs)

# Démarrer l'application
python main.py
```

#### Mode production
```bash
# Avec Gunicorn
export $(cat .env | xargs)
gunicorn --bind 0.0.0.0:5000 --workers 2 --reload main:app

# Ou avec systemd (recommandé)
sudo cp monitoring.service /etc/systemd/system/
sudo systemctl enable monitoring
sudo systemctl start monitoring
```

## 🌐 Accès à l'application

Une fois démarrée, l'application sera accessible sur:
- **Développement**: http://localhost:5000
- **Production**: http://votre-serveur:5000

## 📋 Configuration des équipements

### 1. Ajouter des clients
- Accédez à la section "Clients"
- Cliquez sur "Ajouter un client"
- Remplissez les informations

### 2. Ajouter des équipements
- Accédez à la section "Équipements"
- Cliquez sur "Ajouter un équipement"
- Configurez l'IP et le type (DVR, Caméra, NVR)

### 3. Configuration des DVR/Caméras
Configurez vos équipements pour envoyer des pings HTTP vers:
```
URL: http://votre-serveur:5000/api/ping
Méthode: POST
Content-Type: application/json
Fréquence: 1-2 minutes

Exemple de payload:
{
    "ip": "192.168.1.100",
    "equipement_id": 1,
    "response_time": 50,
    "message": "OK"
}
```

## 🔧 Dépannage

### Problèmes courants

**1. Erreur de base de données**
```bash
# Vérifier la connexion PostgreSQL
psql -h localhost -U monitoring_user -d monitoring_db

# Recréer les tables
python -c "from app import app, db; app.app_context().push(); db.create_all()"
```

**2. Port déjà utilisé**
```bash
# Trouver le processus utilisant le port 5000
sudo lsof -i :5000
sudo kill -9 PID_DU_PROCESSUS
```

**3. Problèmes de permissions**
```bash
# Donner les bonnes permissions
chmod +x main.py
chown -R www-data:www-data /chemin/vers/monitoring_cameras
```

## 📈 Surveillance

### Logs de l'application
```bash
# Voir les logs en temps réel
tail -f /var/log/monitoring.log

# Ou si utilisation de systemd
journalctl -u monitoring -f
```

### Vérification du service
```bash
# Statut du service
sudo systemctl status monitoring

# Redémarrer si nécessaire
sudo systemctl restart monitoring
```

## 🔒 Sécurité

### Configuration firewall
```bash
# Ubuntu/Debian
sudo ufw allow 5000
sudo ufw enable

# CentOS/RHEL
sudo firewall-cmd --permanent --add-port=5000/tcp
sudo firewall-cmd --reload
```

### Reverse proxy (recommandé)
Configuration Nginx pour la production:
```nginx
server {
    listen 80;
    server_name votre-domaine.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

## 📞 Support

En cas de problème:
1. Consultez les logs de l'application
2. Vérifiez la configuration de la base de données
3. Testez la connectivité réseau vers vos équipements
4. Vérifiez que les ports sont ouverts

L'application dispose d'un système de logs détaillé pour faciliter le diagnostic des problèmes.