# Système de Monitoring des Caméras

## Overview

This is a Flask-based web application for monitoring camera and DVR equipment for multiple clients. The system provides real-time monitoring, alerting, and management capabilities for security equipment including cameras, DVRs, and other network devices.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes

- **21 juillet 2025**: Configuration modifiée pour utiliser SQLite local
- Correction des erreurs SQLAlchemy dans les formulaires d'ajout
- Base de données synchronisée entre interface web et fichier local
- Application maintenant compatible avec monitoring_local.db
- **19 juillet 2025**: Application de monitoring déployée avec succès
- Interface web fonctionnelle avec gestion clients/équipements  
- Premier équipement DVR ajouté (192.144.11.1:80) pour client Ayoub
- Système de monitoring automatique actif

## System Architecture

### Backend Architecture
- **Framework**: Flask with SQLAlchemy ORM
- **Database**: SQLite for development with PostgreSQL support for production
- **Scheduling**: APScheduler for background tasks and monitoring
- **Proxy Support**: Werkzeug ProxyFix for deployment behind reverse proxies

### Frontend Architecture
- **Template Engine**: Jinja2 with Flask
- **UI Framework**: Bootstrap with dark theme
- **Icons**: Font Awesome
- **Charts**: Chart.js for data visualization
- **Language**: French interface with some English template variants

## Key Components

### Database Models
1. **Client**: Customer information with relationships to equipment
2. **Equipement**: Network equipment (cameras, DVRs) with IP addresses and monitoring status
3. **HistoriquePing**: Historical ping data for equipment monitoring
4. **Alerte**: Alert system for equipment failures and issues

### Core Modules
1. **app.py**: Main application factory with database configuration
2. **models.py**: SQLAlchemy models defining data structure
3. **routes.py**: Web routes and API endpoints
4. **scheduler.py**: Background monitoring tasks using APScheduler
5. **main.py**: Application entry point

### Monitoring Features
- Real-time equipment status tracking
- Automated ping monitoring every 2 minutes
- Alert generation for offline equipment
- Historical data tracking
- Dashboard with statistics and overview

## Data Flow

1. **Equipment Registration**: Clients and their equipment are registered through web interface
2. **Monitoring Loop**: Background scheduler pings equipment periodically
3. **Status Updates**: Equipment status is updated based on ping responses
4. **Alert Generation**: Alerts are created when equipment goes offline
5. **Dashboard Display**: Real-time status displayed on web dashboard

## External Dependencies

### Python Libraries
- Flask and Flask-SQLAlchemy for web framework and ORM
- APScheduler for background task scheduling
- Werkzeug for WSGI utilities

### Frontend Libraries
- Bootstrap (Replit dark theme variant)
- Font Awesome for icons
- Chart.js for data visualization

### Database
- SQLite for local development
- PostgreSQL support for production deployment
- Automatic database URL conversion for compatibility

## Deployment Strategy

### Development
- SQLite database with file storage
- Debug mode enabled
- Local development server on port 5000

### Production Considerations
- PostgreSQL database via DATABASE_URL environment variable
- Session secret from environment variable
- Database connection pooling with health checks
- Proxy fix for reverse proxy deployment
- Automatic table creation on startup

### Configuration
- Environment-based configuration for database and secrets
- Flexible database URL handling (postgres:// to postgresql:// conversion)
- Connection pooling and ping checks for reliability

The application is designed to be deployable on platforms like Replit, Heroku, or similar PaaS solutions with minimal configuration changes.