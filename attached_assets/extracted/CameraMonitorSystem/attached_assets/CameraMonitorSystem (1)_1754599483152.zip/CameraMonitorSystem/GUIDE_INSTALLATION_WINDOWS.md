# 🪟 Installation Windows - Système de Monitoring Caméras

## Solution Rapide pour votre Erreur

D'après votre erreur, il vous manque le module `apscheduler`. Voici comment résoudre le problème :

### ⚡ Solution Express (Recommandée)

1. **Ouvrez PowerShell en tant qu'administrateur**
2. **Naviguez vers votre dossier** :
   ```powershell
   cd "C:\Users\ayoub\Downloads\CameraMonitorSystem"
   ```

3. **Installez TOUTES les dépendances avec les bonnes versions** :
   ```powershell
   pip install Flask==2.3.3
   pip install Flask-SQLAlchemy==3.0.5
   pip install APScheduler==3.10.4
   pip install Werkzeug==2.3.7
   pip install email-validator==2.1.0
   ```

4. **Configurez les variables d'environnement** :
   ```powershell
   $env:DATABASE_URL="sqlite:///monitoring.db"
   $env:SESSION_SECRET="ma-cle-secrete-windows-123456"
   ```

5. **Lancez l'application** :
   ```powershell
   python main.py
   ```

### 🔧 Alternative avec le Script Automatique

Utilisez le fichier `install_windows.bat` inclus dans l'archive :

1. **Double-cliquez** sur `install_windows.bat`
2. Le script va :
   - Installer automatiquement toutes les dépendances
   - Configurer les variables d'environnement
   - Démarrer l'application

### 📋 Installation Complète Étape par Étape

#### Étape 1: Vérifier Python
```powershell
python --version
```
Vous devriez voir : `Python 3.12.x` (ou plus récent)

#### Étape 2: Installation des Dépendances
```powershell
# Dépendances principales (versions compatibles)
pip install Flask==2.3.3
pip install Flask-SQLAlchemy==3.0.5
pip install APScheduler==3.10.4
pip install Werkzeug==2.3.7
pip install email-validator==2.1.0

# Optionnel pour production
pip install psycopg2-binary
pip install gunicorn
```

#### Étape 3: Configuration Base de Données
**Pour débuter (SQLite - plus simple)** :
```powershell
$env:DATABASE_URL="sqlite:///monitoring.db"
```

**Pour production (PostgreSQL)** :
```powershell
$env:DATABASE_URL="postgresql://user:password@localhost/monitoring_db"
```

#### Étape 4: Configuration Sécurité
```powershell
$env:SESSION_SECRET="votre-cle-secrete-unique-123456"
```

#### Étape 5: Lancement
```powershell
python main.py
```

### 🌐 Accès à l'Application

Une fois démarrée, ouvrez votre navigateur :
- **URL** : http://localhost:5000
- **Dashboard** : http://localhost:5000/dashboard

### ❌ Dépannage Erreurs Courantes

#### Erreur : "ModuleNotFoundError: No module named 'apscheduler'"
```powershell
pip install APScheduler==3.10.4
```

#### Erreur : "ModuleNotFoundError: No module named 'psycopg2'"
```powershell
pip install psycopg2-binary
```

#### Erreur : Port 5000 déjà utilisé
```powershell
# Trouver le processus
netstat -ano | findstr :5000

# Tuer le processus (remplacez XXXX par le PID)
taskkill /PID XXXX /F
```

#### Erreur : Base de données
```powershell
# Supprimer la base existante
del monitoring.db

# Relancer l'application
python main.py
```

### 🔄 Redémarrage Automatique

Pour éviter de retaper les commandes, créez un fichier `start.bat` :

```bat
@echo off
set DATABASE_URL=sqlite:///monitoring.db
set SESSION_SECRET=ma-cle-secrete-windows-123456
python main.py
pause
```

### 🎯 Test Rapide

1. **Démarrez l'application**
2. **Ouvrez** http://localhost:5000
3. **Ajoutez un client** : Clients → Ajouter un client
4. **Ajoutez un équipement** : Équipements → Ajouter un équipement
5. **Testez l'API** avec PowerShell :

```powershell
$body = @{
    ip = "192.168.1.100"
    equipement_id = 1
    response_time = 50
    message = "Test OK"
} | ConvertTo-Json

Invoke-RestMethod -Uri "http://localhost:5000/api/ping" -Method POST -Body $body -ContentType "application/json"
```

### 📞 Support Windows

Si vous avez encore des problèmes :

1. **Vérifiez votre version de Python** : `python --version`
2. **Vérifiez pip** : `pip --version`
3. **Installez dans l'ordre** : Flask → Flask-SQLAlchemy → APScheduler
4. **Utilisez le script automatique** `install_windows.bat`

L'application devrait maintenant fonctionner parfaitement sur Windows !