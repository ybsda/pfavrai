#!/bin/bash

echo "Installation du Système de Monitoring des Caméras - Linux"
echo "=========================================================="

# Vérifier que Python est installé
if ! command -v python3 &> /dev/null; then
    echo "Python3 n'est pas installé. Installation..."
    sudo apt update
    sudo apt install -y python3 python3-pip python3-venv
fi

echo "Installation des dépendances Python..."
pip3 install Flask==2.3.3
pip3 install Flask-SQLAlchemy==3.0.5
pip3 install APScheduler==3.10.4
pip3 install Werkzeug==2.3.7
pip3 install email-validator==2.1.0

echo
echo "Configuration des variables d'environnement..."
export DATABASE_URL="sqlite:///monitoring.db"
export SESSION_SECRET="ma-cle-secrete-linux-123456"

echo
echo "Démarrage de l'application..."
python3 main.py