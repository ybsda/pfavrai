#!/usr/bin/env python3
"""
Script pour créer une base de données SQLite locale
pour le système de monitoring des caméras
"""
import os
import sqlite3
from datetime import datetime

def create_local_database():
    """Crée une base de données SQLite locale avec toutes les tables"""
    
    # Nom du fichier de base de données
    db_file = "monitoring_local.db"
    
    # Supprimer l'ancienne base si elle existe
    if os.path.exists(db_file):
        os.remove(db_file)
        print(f"✓ Ancienne base de données supprimée: {db_file}")
    
    # Créer la connexion
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    
    print(f"✓ Création de la base de données: {db_file}")
    
    # Créer la table clients
    cursor.execute('''
    CREATE TABLE clients (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom VARCHAR(100) NOT NULL,
        adresse TEXT,
        telephone VARCHAR(20),
        email VARCHAR(100),
        date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
        actif BOOLEAN DEFAULT 1
    )
    ''')
    print("✓ Table 'clients' créée")
    
    # Créer la table équipements
    cursor.execute('''
    CREATE TABLE equipements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nom VARCHAR(100) NOT NULL,
        type_equipement VARCHAR(50) NOT NULL,
        adresse_ip VARCHAR(45) NOT NULL,
        port INTEGER DEFAULT 80,
        client_id INTEGER NOT NULL,
        dernier_ping DATETIME,
        date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
        actif BOOLEAN DEFAULT 1,
        FOREIGN KEY (client_id) REFERENCES clients (id)
    )
    ''')
    print("✓ Table 'equipements' créée")
    
    # Créer la table historique_pings
    cursor.execute('''
    CREATE TABLE historique_pings (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        equipement_id INTEGER NOT NULL,
        timestamp_ping DATETIME DEFAULT CURRENT_TIMESTAMP,
        reponse_reussie BOOLEAN DEFAULT 1,
        temps_reponse FLOAT,
        message TEXT,
        FOREIGN KEY (equipement_id) REFERENCES equipements (id)
    )
    ''')
    print("✓ Table 'historique_pings' créée")
    
    # Créer la table alertes
    cursor.execute('''
    CREATE TABLE alertes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        equipement_id INTEGER NOT NULL,
        type_alerte VARCHAR(50) NOT NULL,
        message TEXT NOT NULL,
        timestamp_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
        resolue BOOLEAN DEFAULT 0,
        timestamp_resolution DATETIME,
        FOREIGN KEY (equipement_id) REFERENCES equipements (id)
    )
    ''')
    print("✓ Table 'alertes' créée")
    
    # Ajouter des données d'exemple
    print("\n📊 Ajout de données d'exemple...")
    
    # Client d'exemple
    cursor.execute('''
    INSERT INTO clients (nom, adresse, telephone, email)
    VALUES (?, ?, ?, ?)
    ''', ("Entreprise Test", "123 Rue Example", "01-23-45-67-89", "contact@test.com"))
    
    client_id = cursor.lastrowid
    print(f"✓ Client ajouté (ID: {client_id})")
    
    # Équipements d'exemple
    equipements_test = [
        ("DVR Principal", "DVR", "192.168.1.100", 80),
        ("Caméra Entrée", "Camera", "192.168.1.101", 554),
        ("Caméra Parking", "Camera", "192.168.1.102", 554),
        ("NVR Bureaux", "NVR", "192.168.1.103", 80)
    ]
    
    for nom, type_eq, ip, port in equipements_test:
        cursor.execute('''
        INSERT INTO equipements (nom, type_equipement, adresse_ip, port, client_id)
        VALUES (?, ?, ?, ?, ?)
        ''', (nom, type_eq, ip, port, client_id))
        print(f"✓ Équipement ajouté: {nom} ({ip}:{port})")
    
    # Historique d'exemple
    cursor.execute('''
    INSERT INTO historique_pings (equipement_id, reponse_reussie, temps_reponse, message)
    VALUES (1, 1, 45.2, "Ping réussi")
    ''')
    
    cursor.execute('''
    INSERT INTO historique_pings (equipement_id, reponse_reussie, temps_reponse, message)
    VALUES (2, 0, NULL, "Timeout")
    ''')
    print("✓ Historique d'exemple ajouté")
    
    # Alerte d'exemple
    cursor.execute('''
    INSERT INTO alertes (equipement_id, type_alerte, message)
    VALUES (2, "HORS_LIGNE", "Caméra Entrée ne répond plus depuis 10 minutes")
    ''')
    print("✓ Alerte d'exemple ajoutée")
    
    # Valider les changements
    conn.commit()
    
    # Afficher un résumé
    print("\n📈 Résumé de la base de données:")
    
    cursor.execute("SELECT COUNT(*) FROM clients")
    nb_clients = cursor.fetchone()[0]
    print(f"   Clients: {nb_clients}")
    
    cursor.execute("SELECT COUNT(*) FROM equipements")
    nb_equipements = cursor.fetchone()[0]
    print(f"   Équipements: {nb_equipements}")
    
    cursor.execute("SELECT COUNT(*) FROM historique_pings")
    nb_pings = cursor.fetchone()[0]
    print(f"   Pings: {nb_pings}")
    
    cursor.execute("SELECT COUNT(*) FROM alertes")
    nb_alertes = cursor.fetchone()[0]
    print(f"   Alertes: {nb_alertes}")
    
    # Fermer la connexion
    conn.close()
    
    print(f"\n🎉 Base de données créée avec succès !")
    print(f"📁 Fichier: {os.path.abspath(db_file)}")
    print(f"💾 Taille: {os.path.getsize(db_file)} bytes")
    
    return db_file

def verify_database(db_file):
    """Vérifie que la base de données fonctionne correctement"""
    print(f"\n🔍 Vérification de la base de données...")
    
    conn = sqlite3.connect(db_file)
    cursor = conn.cursor()
    
    # Tester une requête
    cursor.execute('''
    SELECT c.nom as client, e.nom as equipement, e.adresse_ip 
    FROM clients c 
    JOIN equipements e ON c.id = e.client_id
    ''')
    
    results = cursor.fetchall()
    print("✓ Test de requête réussi:")
    for client, equipement, ip in results:
        print(f"   {client} -> {equipement} ({ip})")
    
    conn.close()

if __name__ == "__main__":
    print("🗄️  Création d'une base de données SQLite locale")
    print("=" * 50)
    
    try:
        db_file = create_local_database()
        verify_database(db_file)
        
        print("\n✅ SUCCÈS ! Votre base de données locale est prête.")
        print("\n📋 Prochaines étapes:")
        print("1. Modifiez votre variable DATABASE_URL pour pointer vers ce fichier")
        print("2. Redémarrez votre application")
        print("3. Votre application utilisera maintenant cette base locale")
        
    except Exception as e:
        print(f"❌ Erreur lors de la création: {e}")