import os
import sys
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from werkzeug.middleware.proxy_fix import ProxyFix

# Configuration de logging pour Windows
import logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler('monitoring.log', encoding='utf-8')
    ]
)

# Création de l'application Flask
app = Flask(__name__)

# Configuration pour Windows avec base SQLite locale
app.config['SECRET_KEY'] = os.environ.get('SESSION_SECRET', 'windows-local-secret-key-123456')

# Base de données SQLite locale pour Windows
database_path = os.path.join(os.path.dirname(__file__), 'monitoring_local.db')
app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{database_path}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SQLALCHEMY_ENGINE_OPTIONS'] = {
    "pool_timeout": 20,
    "pool_recycle": -1,
    "pool_pre_ping": True
}

# Configuration pour débogage Windows
app.config['DEBUG'] = True
app.config['TEMPLATES_AUTO_RELOAD'] = True

# Middleware pour proxy (optionnel pour Windows local)
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Initialisation SQLAlchemy
db = SQLAlchemy(app)

# Création des tables au démarrage
with app.app_context():
    try:
        # Import des modèles pour créer les tables
        from models import Client, Equipement, HistoriquePing, Alerte
        
        # Créer toutes les tables
        db.create_all()
        
        logging.info("✅ Base de données SQLite initialisée avec succès")
        logging.info(f"📁 Fichier de base: {database_path}")
        
        # Vérifier si la base contient des données
        client_count = Client.query.count()
        if client_count == 0:
            logging.info("🔄 Base vide détectée, ajout de données d'exemple...")
            
            # Client d'exemple
            client_test = Client(
                nom="Entreprise Test Windows",
                adresse="123 Rue Windows", 
                telephone="01-23-45-67-89",
                email="test@windows.local"
            )
            db.session.add(client_test)
            db.session.commit()
            
            # Équipements d'exemple
            equipements = [
                Equipement(nom="DVR Principal", type_equipement="DVR", adresse_ip="192.168.1.100", port=80, client_id=client_test.id),
                Equipement(nom="Caméra Entrée", type_equipement="Camera", adresse_ip="192.168.1.101", port=554, client_id=client_test.id),
                Equipement(nom="Caméra Parking", type_equipement="Camera", adresse_ip="192.168.1.102", port=554, client_id=client_test.id)
            ]
            
            for eq in equipements:
                db.session.add(eq)
            
            db.session.commit()
            logging.info("✅ Données d'exemple ajoutées")
        
    except Exception as e:
        logging.error(f"❌ Erreur lors de l'initialisation: {e}")

# Import des routes
try:
    import routes
    import scheduler
    logging.info("✅ Routes et planificateur chargés")
except ImportError as e:
    logging.error(f"❌ Erreur lors de l'import des modules: {e}")

if __name__ == '__main__':
    print("🔧 Système de Monitoring des Caméras - Version Windows")
    print("=" * 55)
    print(f"📁 Base de données: {database_path}")
    print(f"🌐 URL: http://localhost:5000")
    print("=" * 55)
    
    try:
        app.run(
            host='0.0.0.0',
            port=5000,
            debug=True,
            use_reloader=True,
            threaded=True
        )
    except Exception as e:
        logging.error(f"❌ Erreur lors du démarrage: {e}")
        input("Appuyez sur Entrée pour continuer...")